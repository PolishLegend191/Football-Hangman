
#final

import random as r

list1 = [["bankrupt", 200, 200, 200, 250, 250, 300,
          300, 350, 350, 400, 400, 450, 450, 500, 750, 750, 1000],
         ["bankrupt", "bankrupt", "?", 200, 250, 250, 300,
          300, 350, 350, 400, 400, 450, 450, 500, 750, 1000, 1500],
         ["bankrupt", "bankrupt", "?", "?", 250, 250, 300,
          300, 350, 350, 400, 400, 450, 450, 500, 750, 1000, 1750]]

finalList = [2000, 2000, 2000, 2500, 2500, 2500, 3000, 3000, 3000, 4000, 4000, 5000, 7500]

def wheelSpin (list):
    value = r.choice(list)
    return value

def letterChecker(guess, dataset):
    count = 0
    global ans
    global ansOut
    for y in range(len(ans)):
        letter = ans[y]
        if letter == guess:
            ansOut[y] = guess
            count = count + 1
            if count == 1:
                dataset.remove(guess)
    return count, ansOut, dataset

def letterChecker2(guess):
    global ans
    global ansOut
    for y in range(len(ans)):
        letter = ans[y]
        if letter == guess:
            ansOut[y] = guess
    return ansOut

def letterType(listOfLetters, Userletter):
    check = False
    for x in range(len(listOfLetters)):
        letter = listOfLetters[x]
        if letter == Userletter:
            check = True
    return check

def anyLettersInAns():
    global ansOut
    checking = 0
    for a in range(len(ansOut)):
        if (ansOut[a] != "_") and (ansOut[a] != "/"):
            checking = checking + 1
    return checking
        

wonRounds = 0
comp_wonRounds = 0
totalScore = 0
comp_totalScore = 0
anotherGo = True


print("Hey there! Have you played this game before? ")
rulesChoice = input("Yes or No? ").upper()
while (rulesChoice != "YES") and (rulesChoice != "NO"):
    rulesChoice = input("Re-enter Yes or No: ").upper()
print("")

if rulesChoice == "NO":
    print("This is Foobtall Hangman\n"
          "The main aim is to win the most score\n"
          "This is a two player game: 'you' and the 'computer'\n"
          "\n"
          "There are 3 rounds based on a football club\n"
          "Each player takes in turn starting with 'you'\n"
          "If you guess correctly you get another turn\n"
          "\n"
          "There are three options:\n"
          "1. Guess a consonant to win score\n"
          "2. Buy a vowel for 200 score - can not buy with under 200 score\n"
          "3. Guess answer to progress to next round with bonus 1000 score - can not guess with no letters\n"
          "\n"
          "There is a wheel however; it is spun to receive a value\n"
          "It will either be a score, a bankrupt where score resets to 0, or a choice to gamble\n"
          "\n"
          "Whoever gets the most after the 3 rounds enters the final based on a footballer\n"
          "Here you will be given 3 random letters and 1 random vowel and a choice of 4 consonants and 1 vowel\n"
          "")

print("")


for roundNumber in range(0, 3):
    print("ROUND", roundNumber+1, "...")
    print("")
    
    whoStarts = r.randint(0,1)
    if whoStarts == 0:
      anotherGo = True
      print("You start...")
    elif whoStarts == 1:
      anotherGo = False
      print("Computer starts...")
    print("")

    gameCheck = False
    totalRoundScore = 0
    comp_totalRoundScore = 0
    count = 0
    ans = ""
    subject = ""

    

    listOfTeams = [["Manchester/City","Liverpool","Chelsea","Manchester/United",
                    "Arsenal","Tottenham/Hotspur","Leicester/City","West/Ham/United",
                    "Everton","Leeds/United","Aston/Villa","Newcastle/United",
                    "Wolverhampton/Wanderers","Crystal/Palace","Southampton","Brighton",
                    "Burnley","Fulham","West/Bromwich/Albion","Sheffield/United"],
                   ["Real/Madrid","Barcelona","Atletico/Madrid","Sevilla",
                   "Villarreal","Real/Sociedad","Real/Betis","Athletic/Bilbao",
                   "Valencia","Celta/Vigo","Espanyol","Getafe",
                   "Granada","Levante","Osasuna","Alaves",
                   "Cadiz","Mallorca","Elche","Rayo/Vallecano"],
                   ["Bayern/Munich","Borussia/Dortmund","RB/Leipzig","Bayer/Leverkusen",
                    "Borussia/Monchengladbach","Wolfsburg","Eintracht/Frankfurt","Union/Berlin",
                    "Stuttgart","Hoffenheim","Freiburg","Hertha",
                    "Augsburg","Mainz","Arminia/Bielefeld","Cologne",
                    "Werder/Bremen","Greuther/Furth","Bochum","St/Pauli"],
                   ["Inter/Milan","AC/Milan","Napoli","Juventus",
                    "AS/Roma","Lazio","Atalanta","Sassuolo",
                    "Fiorentina","Torino","Verona","Udinese",
                    "Bologna","Cagliari","Spezia","Genoa",
                    "Sampdoria","Empoli","Salernitana","Venezia"],
                    ["Paris/Saint/Germain","Lille","Olympique/Marseille","Monaco",
                    "Lyon","Rennes","Lens","Montpellier",
                    "Nice","Saint/Etienne","Reims","Bordeaux",
                    "Strasbourg","Metz","Nantes","Angers",
                    "Lorient","Troyes","Clermont/Foot","Brest"],
                    ["River/Plate","Boca/Juniors","Newells/Old/Boys","Santos",
                    "Palmeiras","Corinthians","Sao/Paulo","Botafogo",
                    "Gremio","Flamengo","Fluminense","Cruz/Azul",
                    "Club/America","Tigres","Inter/Miami","LA/Galaxy",
                    "DC/United","Nashville","Atalanta/United","Philadelphia"],
                    ["Benfica","Sporting/Lisbon","Porto","Braga",
                    "Anderlecht","Gent","Genk","Royal/Antwerp",
                    "Union/St/Gilloise","Club/Brugge","PSV/Eindhoven","Feyenoord",
                    "Ajax","Az/Alkmaar","Twente","Copenhagen","Midtjylland",
                    "Molde","Bodo/Glimt","Malmo","Young/Boys",
                    "Basel","Aberdeen","Celtic","Rangers"]]
    league = r.randint(0,6)
    leagueLength = listOfTeams[league]
    club = r.randint(0, (len(leagueLength)-1))
    ans = listOfTeams[league][club].lower()

    if league == 0:
        subject = "Team from England"
    elif league == 1:
        subject = "Team from Spain"
    elif league == 2:
        subject = "Team from Germany"
    elif league == 3:
        subject = "Team from Italy"
    elif league == 4:
        subject = "Team from France"
    elif league == 5:
        subject = "Team from America"
    elif league == 6:
        subject = "Team from Rest of Europe"

    firstAns = ans
    ansOut = []
    ans.split()
    ans = list(ans)

    for z in range(len(ans)):
        if ans[z] == "/":
            ansOut.append("/",)
        else:
            ansOut.append("_",)
        



    consonants = ["b", "c", "d", "f", "g", "h",
                  "j", "k", "l", "m", "n", "p",
                  "q", "r", "s", "t", "v",
                  "w", "x", "y", "z"]

    vowels = ["a", "e", "i", "o", "u"]

    comp_Consonants = ["b", "c", "d", "f", "g", "h",
                      "j", "k", "l", "m", "n", "p",
                      "q", "r", "s", "t", "v",
                      "w", "x", "y", "z"]

    comp_Vowels = ["a", "e", "i", "o", "u"]



    print("Subject =", subject)
    print('[' + ' '.join(ansOut) + ']')
    print("")

    while gameCheck == False:
        while (anotherGo == True) and (gameCheck == False):
            print("Your turn...")
            scoreGenerated = wheelSpin(list1[roundNumber])
            if scoreGenerated == "bankrupt":
                anotherGo = False
                if totalRoundScore > 0:
                    totalRoundScore = 0
                    print("BANKRUPT")
                    print("")
                else:
                    print("BANKRUPT - nothing lost")
                    print("")
            elif scoreGenerated == "?":
                print("Do you wish to GAMBLE; BANKRUPT or 2000")
                gamble = input("Yes or no? ").lower()
                while (gamble != "yes") and (gamble != "no"):
                    gamble = input("Re-enter yes or no? ").lower()
                if gamble == "yes":
                    gambleResult = r.randint(0,1)
                    if gambleResult == 0:
                        anotherGo = False
                        if totalRoundScore > 0:
                            totalRoundScore = 0
                            print("BANKRUPT")
                            print("")
                        else:
                            print("BANKRUPT - nothing lost")
                            print("")
                    elif gambleResult == 1:
                        print("Gamble payed off!")
                        scoreGenerated = 2000

            if (scoreGenerated != "bankrupt") and (scoreGenerated != "?"):
                print("Enter 'g' to guess a consonant")
                print("Enter 'b' to buy a vowel for 200 score")
                print("Enter 'a' to guess a the answer")
                checkForIt = anyLettersInAns()
                decision = input("Decide: ").lower()
                while (decision != "g") and (decision != "b") and (decision != "a") or ((decision == "a") and (checkForIt == 0)) or ((decision == "b") and (totalRoundScore < 200)):
                    if (decision != "g") and (decision != "b") and (decision != "a"):
                        print("Wrong input!")
                        decision = input("Re-enter decision (g/b/a)").lower()
                    elif (decision == "a") and (checkForIt == 0):
                        print("Guess some letters first!")
                        decision = input("Re-enter decision (g/b/a)").lower()
                    elif (decision == "b") and (totalRoundScore < 200):
                        print("Not enough money!")
                        decision = input("Re-enter decision (g/b/a)").lower()
                if decision == "b":
                    vowel = input("Enter vowel: ").lower()
                    checkForLetter = letterType(vowels, vowel)
                    while checkForLetter == False:
                        vowel = input("Re-enter vowel: ").lower()
                        checkForLetter = letterType(vowels, vowel)
                    result = letterChecker(vowel, vowels)
                    vowels = result[2]
                    
                    print('[' + ' '.join(result[1]) + ']')
                    print("-200 score")
                    totalRoundScore = totalRoundScore - 200
                    if result[0] > 0:
                        anotherGo = True
                    else:
                        anotherGo = False
                elif decision == "a":
                    answer = input("Enter full answer: ")
                    if answer == firstAns:
                        totalRoundScore = totalRoundScore + 1000
                        print("You won =", totalRoundScore)
                        wonRounds = wonRounds + 1
                        anotherGo = True
                        gameCheck = True
                    else:
                        print("Wrong, -300 score")
                        totalRoundScore = totalRoundScore - 300
                        anotherGo = False
                else:
                    print("Result from spin =", scoreGenerated)
                    consonant = input("Enter consonant: ").lower()
                    checkForLetter = letterType(consonants, consonant)
                    while checkForLetter == False:
                        consonant = input("Re-enter consonant: ").lower()
                        checkForLetter = letterType(consonants, consonant)
                    result = letterChecker(consonant, consonants)
                    consonants = result[2]
                    
                    scoreFromChecker = scoreGenerated * result[0]
                    print("Score won=", scoreFromChecker)
                    print('[' + ' '.join(result[1]) + ']')
                    totalRoundScore = totalRoundScore + scoreFromChecker
                    print("")
                    if result[0] > 0:
                        anotherGo = True
                    else:
                        anotherGo = False

        while (anotherGo == False) and (gameCheck == False):
            print("Computer turn...")
            comp_scoreGenerated = wheelSpin(list1[roundNumber])
            if comp_scoreGenerated == "bankrupt":
                anotherGo = True
                if comp_totalRoundScore > 0:
                    comptotalRoundScore = 0
                    print("BANKRUPT")
                    print("")
                else:
                    print("BANKRUPT - nothing lost")
                    print("")
            elif comp_scoreGenerated == "?":
                print("Do you wish to GAMBLE; BANKRUPT or 2000")
                comp_gamble = input("Yes or no? ").lower()
                while (comp_gamble != "yes") and (comp_gamble != "no"):
                    comp_gamble = input("Re-enter yes or no? ").lower()
                if comp_gamble == "yes":
                    comp_gambleResult = r.randint(0,1)
                    if comp_gambleResult == 0:
                        anotherGo = True
                        if comp_totalRoundScore > 0:
                            comp_totalRoundScore = 0
                            print("BANKRUPT")
                            print("")
                        else:
                            print("BANKRUPT - nothing lost")
                            print("")
                    elif comp_gambleResult == 1:
                        print("Gamble payed off!")
                        comp_scoreGenerated = 2000

            if (comp_scoreGenerated != "bankrupt") and (comp_scoreGenerated != "?"):
                print("Enter 'g' to guess a consonant")
                print("Enter 'b' to buy a vowel for 200 score")
                print("Enter 'a' to guess a the answer")
                checkForIt = anyLettersInAns()
                comp_decision = input("Decide: ").lower()
                while (comp_decision != "g") and (comp_decision != "b") and (comp_decision != "a") or ((comp_decision == "a") and (checkForIt == 0)) or ((comp_decision == "b") and (comp_totalRoundScore < 200)):
                    if (comp_decision != "g") and (comp_decision != "b") and (comp_decision != "a"):
                        print("Wrong input!")
                        comp_decision = input("Re-enter decision (g/b/a)").lower()
                    elif (comp_decision == "a") and (checkForIt == 0):
                        print("Guess some letters first!")
                        comp_decision = input("Re-enter decision (g/b/a)").lower()
                    elif (comp_decision == "b") and (comp_totalRoundScore < 200):
                        print("Not enough money!")
                        comp_decision = input("Re-enter decision (g/b/a)").lower()
                if comp_decision == "b":
                    comp_vowel = input("Enter vowel: ").lower()
                    comp_checkForLetter = letterType(vowels, comp_vowel)
                    while checkForLetter == False:
                        comp_vowel = input("Re-enter vowel: ").lower()
                        comp_checkForLetter = letterType(vowels, comp_vowel)
                    comp_result = letterChecker(comp_vowel, vowels)
                    vowels = comp_result[2]
                    
                    print('[' + ' '.join(comp_result[1]) + ']')
                    print("-200 score")
                    comp_totalRoundScore = comp_totalRoundScore - 200
                    if comp_result[0] > 0:
                        anotherGo = False
                    else:
                        anotherGo = True
                elif comp_decision == "a":
                    comp_answer = input("Enter full answer: ")
                    if comp_answer == firstAns:
                        comp_totalRoundScore = comp_totalRoundScore + 1000
                        print("You won =", comp_totalRoundScore)
                        comp_wonRounds = comp_wonRounds + 1
                        anotherGo = True
                        gameCheck = True
                    else:
                        print("Wrong, -300 score")
                        comp_totalRoundScore = comp_totalRoundScore - 300
                        anotherGo = True
                        
                else:
                    print("Result from spin =", comp_scoreGenerated)
                    comp_consonant = input("Enter consonant: ").lower()
                    comp_checkForLetter = letterType(consonants, comp_consonant)
                    while comp_checkForLetter == False:
                        comp_consonant = input("Re-enter consonant: ").lower()
                        comp_checkForLetter = letterType(consonants, comp_consonant)
                    comp_result = letterChecker(comp_consonant, consonants)
                    consonants = comp_result[2]
                    
                        
                    comp_scoreFromChecker = comp_scoreGenerated * comp_result[0]
                    print("Score won=", comp_scoreFromChecker)
                    print('[' + ' '.join(comp_result[1]) + ']')
                    comp_totalRoundScore = comp_totalRoundScore + comp_scoreFromChecker
                    print("")
                    if comp_result[0] > 0:
                        anotherGo = False
                    else:
                        anotherGo = True

    totalScore = totalScore + totalRoundScore
    comp_totalScore = comp_totalScore + comp_totalRoundScore

print("")            
print("Your Total after all 3 rounds=", totalScore)
print("Comp Total after all 3 rounds=", comp_totalScore)
print("")            

if totalScore > comp_totalScore:
  print("You win by", totalScore - comp_totalScore)
  print("You qualified for Grand Final!")
  winningScore = totalScore
elif totalScore < comp_totalScore:
  print("Computer wins by", comp_totalScore - totalScore)
  print("Computer qualified for Grand Final!")
  winningScore = comp_totalScore
else:
  if wonRounds > comp_wonRounds:
      print("You win on rounds")
      print("You qualified for Grand Final!")
      winningScore = totalScore
  else:
      print("Computer wins on rounds")
      print("Computer qualified for Grand Final!")
      winningScore = comp_totalScore


print("")
print("GRAND FINAL ...")
print("")

print("Subject = Football player")
print("")




listOfPlayers = [
    "lionel/messi",
    "cristiano/ronaldo",
    "neymar/jr",
    "kylian/mbappe",
    "mohamed/salah",
    "robert/lewandowski",
    "kevin/de/bruyne",
    "sadio/mane",
    "virgil/van/dijk",
    "sergio/ramos",
    "harry/kane",
    "erling/haaland",
    "luka/modric",
    "joshua/kimmich",
    "karim/benzema",
    "romelu/lukaku",
    "bruno/fernandes",
    "raheem/sterling",
    "paul/pogba",
    "gareth/bale",
    "joao/cancelo",
    "andrew/robertson",
    "jadon/sancho",
    "toni/kroos",
    "thomas/muller",
    "eden/hazard",
    "lautaro/martinez",
    "frenkie/de/jong",
    "kai/havertz",
    "mason/mount",
    "ciro/immobile",
    "zlatan/ibrahimovic",
    "marquinhos",
    "thiago/silva",
    "hakim/ziyech",
    "gianluigi/donnarumma",
    "dani/carvajal",
    "jorginho",
    "jordan/henderson",
    "dries/mertens",
    "nicolas/pepe",
    "kasper/schmeichel",
    "wojciech/szczesny",
    "heung/min/son",
    "joao/felix",
    "marcus/rashford",
    "alphonso/davies",
    "jordan/pickford"
]

pos = r.randint(0,47)

firstAns = listOfPlayers[pos]
ans = firstAns

ansOut = []
ans.split()
ans = list(ans)

for z in range(len(ans)):
    if ans[z] == "/":
        ansOut.append("/",)
    else:
        ansOut.append("_",)

consonants = ["b", "c", "d", "f", "g", "h",
             "j", "k", "l", "m", "n", "p",
             "q", "r", "s", "t", "v",
             "w", "x", "y", "z"]

vowels = ["a", "e", "i", "o", "u"]

givenLetters = []
for z in range(3):
    givenLetter = r.choice(consonants)
    consonants.remove(givenLetter)
    givenLetters.append(givenLetter)

givenLetter = r.choice(vowels)
vowels.remove(givenLetter)
givenLetters.append(givenLetter)
print("Letters we give you...")
print('[' + ' '.join(givenLetters) + ']')
print("")

for x in range(4):
    print("Enter consonant number", x+1, ":")
    letterToAdd = input().lower()
    checkType = letterType(consonants, letterToAdd)
    while checkType == False:
        print("Re-enter consonant number", x+1, ":")
        letterToAdd = input().lower()
        checkType = letterType(consonants, letterToAdd)
    consonants.remove(letterToAdd)
    givenLetters.append(letterToAdd)


letterToAdd = input("Enter a vowel: ").lower()
checkType = letterType(vowels, letterToAdd)
while checkType == False:
    print("Re-enter a vowel")
    letterToAdd = input().lower()
    checkType = letterType(vowels, letterToAdd)
givenLetters.append(letterToAdd)

for y in range(len(givenLetters)):
    current = givenLetters[y]
    result = letterChecker2(current)

print('[' + ' '.join(result) + ']')

finalRoundScore = wheelSpin(finalList)
answer = input("Enter full answer: ")
print("")

if answer == firstAns:
    print("CORRECT!")
    print("You won =", finalRoundScore)
    print("")
    grandFinalScore = winningScore + finalRoundScore
    print("GRAND FINAL SCORE=", grandFinalScore)
else:
    print("INCORRECT!")
    print("Answer was", firstAns)
    print("You could have won=", finalRoundScore)





